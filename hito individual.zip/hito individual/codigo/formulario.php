<!DOCTYPE html>
<html>
<head>
    <title>Formulario</title>
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
    <h1>Formulario</h1>
    <form action="carga.php" method="post" enctype="multipart/form-data">
        <label for="author_email">Email del autor:</label>
        <input type="email" name="author_email" required>

        <label for="title">Título:</label>
        <input type="text" name="title" required>

        <label for="content">Contenido:</label>
        <textarea name="content" required></textarea>

        <label for="publish_date">Fecha de publicación:</label>
        <input type="date" name="publish_date" required>

        <label for="image">Imagen:</label>
        <input type="file" name="image" accept="image/*">

        <input type="submit" value="Enviar">
        <?php
if(isset($_POST['email']) && isset($_POST['titulo']) && isset($_POST['contenido'])){
    $ID_FORMULARIO=$_POST['ID_FORMULARIO'];
    $email=$_POST['email'];
    $titulo=$_POST['titulo'];
    $fechapublicacion=$_POST['fechapublicacion'];
    $imagen=$_POST['imagen'];
    $contenido=$_POST['contenido'];
    $conn = new PDO('mysql:host=localhost;dbname=hito individual 2 trimestre', 'root', '');
    $insertar= "INSERT INTO `formulario` (`ID_FORMULARIO`, `email`, `titulo`, `fechapublicacion`, `imagen`,`contenido`) VALUES (NULL,''$ID_FORMULARIO'' ,'$email', '$titulo', '$fechapublicacion', '$imagen','$contenido');";
    $registros = $conn->exec($insertar);
    header("location:autentificacion.php");
}
?>
    </form>
</body>
</html>
