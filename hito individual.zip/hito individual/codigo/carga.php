<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hito individual 2 trimestre";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Error al conectar a la base de datos: " . mysqli_connect_error());
}

$author_email = $_POST['author_email'];
$title = $_POST['title'];
$content = $_POST['content'];
$publish_date = $_POST['publish_date'];
$image = $_FILES['image']['name'];

if(isset($_FILES['image'])){
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES['image']['name']);
    move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
    header('Location: autentificacion.php');


}

$sql = "INSERT INTO formulario (email, titulo, fechapublicacion, imagen, contenido) VALUES ('$author_email', '$title', '$publish_date', '$image', '$content')";

if (mysqli_query($conn, $sql)) {
    echo "El post se ha creado correctamente.";
} else {
    echo "Error al crear el post: " . mysqli_error($conn);
}

mysqli_close($conn);
?>