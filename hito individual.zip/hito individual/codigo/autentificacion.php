<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.2/css/bootstrap.min.css" integrity="sha512-K8lqrcoBcfsSBCzvA/57nHb4NpsUS4F4bWRZ9uVpE8GmlPVxIZrPzE+onTcT1zUhWL0GYsMgOlhjXhtHfZ8oOQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Validar</title>
</head>
<body>
    <h1>Validar</h1>
    <div class="container mt-5">
        <form method="post">
            <div class="mb-3">
                <label for="email" class="form-label">Dirección de correo</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="mb-3">
                <label for="contraseña" class="form-label">Contraseña</label>
                <input type="password" class="form-control" id="contraseña" name="contraseña">
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>

        <?php
        if (isset($_POST['email']) && isset($_POST['contraseña'])) {
            session_start();
            $token = session_id();
            echo '<div class="alert alert-success mt-3" role="alert">Ha iniciado sesión con su ID: ' . $token . '</div>';
        }
        ?>

    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.2/js/bootstrap.bundle.min.js" integrity="sha512-6GjH9jylzvZIcQZoYsLsRQmqiMcEnN4c4zuN4A32zj6fMpz/fUPhbGZS57TJjH0x2OyPV6yoI4UX4bgf6pLq6A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
</html>